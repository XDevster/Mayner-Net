::     vistas team     ::
::        2024         ::
@echo off
:load1
setlocal enabledelayedexpansion
call Hone\maynercore.bat
mode con: cols=50 lines=10
set /a cols=50
set /a lines=10
set /a temp2=0
set /p temp6=< %~2
set /a temp7=0
for /f "tokens=1,2,3 delims=," %%A in ("!temp6!") do (
    set /a temp7=!temp7!+1
    if !temp7!==2 (goto :load2)
    set BG=%%A
    set XP=%%B
    set YP=%%C
)
:load2
del "temp\MapTemp.tmp"
for /f "tokens=1,2,3,4 delims=," %%A in (%~2) do (
    set /a temp2+=1
    set "mapPos!temp2!=%%A,%%B"
    set "mapColor!temp2!=%%C"
    if %%D==1 (
        echo %%A,%%B>>temp\MapTemp.tmp
    )
)
set "PXY=0"
set /a gravity=1
set /a temp=0
set /a temp3=0

:loop
call :control
call :physics temp\MapTemp.tmp
call :render
call %~1
set /a temp3=0
set /a collision=0
goto loop

:render
set "cmdgfx_command="
for /l %%i in (1, 1, !temp2!) do (
    set "cmdgfx_command=!cmdgfx_command! pixel !mapColor%%i! !mapColor%%i! @ !mapPos%%i! & "
)
set "cmdgfx_command=!cmdgfx_command! pixel 2 2 @ %XP%,%YP%"
hone\cmdgfx "!cmdgfx_command!"
goto :EOF

:physics
::проверка на столкновения
for /f "tokens=1,2 delims=," %%A in (%~1) do (
    set /a temp5=%YP%+1
    if !temp5! == %%B if !XP! == %%A (
        set /a collision=1
    )
    set /a temp5=%YP%-1
    if !temp5! == %%B if !XP! == %%A (
        set /a collision=2
    )
    if !XP! equ %%A if !YP! equ %%B (
        for /f "tokens=1,2 delims=," %%D in ("!PXY!") do (
            if %temp3%==2 (
                set /a XP-=1
            ) else (
                if %temp3%==1 (
                    set /a XP+=1
                ) 
            )
        )
    )
)
if !collision!==1 set /a YP-=1
if !collision!==2 set /a YP+=1 & set /a gravity=1
if !gravity! == 1 (
    set /a YP+=1
)

if !gravity!==0 (
    set /a temp+=1
)
if !gravity! == 0 (
    set /a YP-=1  
)
if !temp!==3 (
    set /a temp=0
    set /a gravity=1
)
::map

goto :EOF

:control
hone\GetInput /T 0 /I "wad"
if !Errorlevel!==1 (
        set /a gravity=0
)
if !Errorlevel!==2 (
    set /a temp3=1
    set /a XP-=1
)
if !Errorlevel!==3 (
    set /a temp3=2
    set /a XP+=1
)
goto :EOF