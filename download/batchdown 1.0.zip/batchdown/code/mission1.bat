::НЕ ПЫТЙАЙТЕСЬ ИЗМЕНИТЬ КОД!
%h%%c% %XP% == 47 (
%e%%a%%t%
%u%%e%%s%%b%                     v%h%%e%%g%%b%ry
%u%%e%%s%%b%               %q%r%u%%t%%t% %d%ny k%u%y %g%%b% %u%%p%%h%%g%
%q%%d%%f%%t%%u%>n%f%%j%
%u%%p%%h%%g%
)


