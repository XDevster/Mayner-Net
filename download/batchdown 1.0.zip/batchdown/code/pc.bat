@echo off
%g%%h%%g%%a%%u% B%d%%g%%e%%s%D%b%wn - %Am%%h%%t%%t%%h%%b%n 3 - P%u%n%g%%d%%o%%b%n H%d%%e%k%h%n%o%...
%l%%b%d%u% %e%%b%n: %e%%b%%j%%t%=120 %a%%h%n%u%%t%=30
:1
H%b%n%u%\C%b%nS%s%%b%wC%f%r%t%%b%r /%t%h%b%w
echo 50 65 6E 74 61 67 6F 6E 20 64 61 74 61
echo 64 6F 6E 74 20 73 68 61 72 65 20 74 68 69 73
echo D0 A5 D0 B5 D0 B9 21 20 D1 8D D1 82 D0 BE 20 D0 B8 D0 B3 D1 80 D0 B0 20 D1 8D D1 82 D0 BE 20 D0 BD D0 B5 20 D1 80 D0 B5 D0 B0 D0 BB D1 8C D0 BD D0 BE 21
echo ENG
echo 48 65 79 21 20 49 74 73 20 4A 75 73 74 20 67 61 6D 65 20 69 74 73 20 6E 6F 74 20 72 65 61 6C
%u%%e%%s%%b% %e%%b%%l%%l%%d%nd 1./%t%%f%d%b% %t%%h%%g%%u% %h%n%c%%b%
%u%%e%%s%%b% %e%%b%%l%%l%%d%nd 2./%t%%f%d%b% %e%%q%%d%n%u%%j% %j%%b%%o%%h%n
%t%%u%%g% /%q% %e%%l%d=%e%%b%%l%%l%%d%nd:
%h%%c% "%cmd%"=="/%t%%f%d%b% %t%%h%%g%%u% %h%n%c%%b%" (
%o%%b%%g%%b% %h%n%c%
)
%h%%c% "%cmd%"=="/%t%%f%d%b% %e%%q%%d%n%u%%a% %a%%b%%o%%h%n" (
%o%%b%%g%%b% %e%%q%%d%n%u%%a%
)

:inf
echo ----Info----
echo.
echo password (Encrypted): 67 6A 70 6E 67 73 73
echo country: ???
%q%%d%%f%%t%%u%>n%f%%a%
%e%%a%%t%
goto 1
)

:cpanel
echo -------------Welcom To Cpanel------------
echo Username Hoster_usr4569238633
%t%%u%%g% /%q% %q%%d%%t%%t%=%q%%d%%t%%t%w%b%rd:
%h%%c% "%pass%"=="%o%j%q%n%o%%t%%t%" (
%o%%b%%g%%b% b%h%n%d%ry
)

:binary
%e%%b%%a%%b%r 2
%g%%h%%g%%a%%u% B%d%%g%%e%hD%b%wn - %Am%%h%%t%%t%%h%%b%n 3 - P%u%n%g%%d%%o%%b%n H%d%%e%k%u%d!
echo %random% %random% %random% %random% %random% %random% %random% %random% %random%
%o%%b%%g%%b% b%h%n%d%ry