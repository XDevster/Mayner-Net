%h%%c% %XP% == 3 (
%e%%a%%t%
%e%%d%%a%%a% %e%%b%d%u%\%q%%e%.b%d%%g%
)